import React from "react";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="flex justify-between items-center p-4 shadow-md bg-white">
        <h1 className="text-2xl font-bold">Lokal Drops</h1>
        <div className="flex gap-2 items-center">
          <input className="border p-2 rounded w-64" placeholder="Buscar produtos..." />
          <button className="bg-blue-500 text-white px-4 py-2 rounded">Buscar</button>
          <button className="text-blue-500 ml-2">🛒</button>
        </div>
      </header>
      <section className="p-6 text-center bg-gradient-to-r from-blue-100 to-purple-200">
        <motion.h2
          className="text-3xl font-bold mb-4"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          Bem-vindo à sua loja automatizada com IA
        </motion.h2>
        <p className="text-lg">Produtos de alta rentabilidade escolhidos por inteligência artificial.</p>
      </section>
      <section className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 p-6">
        {[1, 2, 3].map((item) => (
          <div key={item} className="bg-white rounded-2xl shadow-lg p-4">
            <img
              src={`https://source.unsplash.com/400x300/?tech,product&sig=${item}`}
              alt="Produto"
              className="rounded-xl mb-4 w-full"
            />
            <h3 className="text-xl font-semibold mb-2">Produto Inteligente #{item}</h3>
            <p className="text-sm text-gray-600 mb-4">Descrição gerada por IA.</p>
            <button className="bg-green-500 text-white w-full py-2 rounded">Comprar Agora</button>
          </div>
        ))}
      </section>
      <footer className="p-4 text-center text-sm text-gray-500">
        &copy; 2025 Lokal Carioca Comércio e Serviços de Informática Ltda
      </footer>
    </div>
  );
}
